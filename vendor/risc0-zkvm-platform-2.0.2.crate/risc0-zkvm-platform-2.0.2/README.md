Platform definitions for the RISC Zero zkVM, including IO port addresses,
memory regions, and low-level runtime functions.
